// Sample data for food items
const menuItems = [
    { id: 1, name: "Pizza", price: 12.99, image: "https://via.placeholder.com/150" },
    { id: 2, name: "Burger", price: 8.99, image: "https://via.placeholder.com/150" },
    { id: 3, name: "Pasta", price: 10.99, image: "https://via.placeholder.com/150" },
    { id: 4, name: "Salad", price: 6.99, image: "https://via.placeholder.com/150" }
];

let cart = [];

// Function to display menu items
function displayMenu() {
    const menuContainer = document.getElementById("menu-items");
    menuItems.forEach(item => {
        const menuItem = document.createElement("div");
        menuItem.classList.add("menu-item");

        menuItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <h3>${item.name}</h3>
            <p>$${item.price}</p>
            <button onclick="addToCart(${item.id})">Add to Cart</button>
        `;
        menuContainer.appendChild(menuItem);
    });
}

// Function to add item to the cart
function addToCart(itemId) {
    const item = menuItems.find(i => i.id === itemId);
    const itemInCart = cart.find(i => i.id === itemId);

    if (itemInCart) {
        itemInCart.quantity += 1;
    } else {
        cart.push({ ...item, quantity: 1 });
    }

    updateCartCount();
}

// Update the cart count in the header
function updateCartCount() {
    document.getElementById("cart-count").textContent = cart.length;
}

// Call displayMenu() to show food items when the page loads
displayMenu();
