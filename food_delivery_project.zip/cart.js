// Function to display the cart items
function displayCart() {
    const cartContainer = document.getElementById("cart-items");
    const totalPrice = document.getElementById("total-price");
    cartContainer.innerHTML = ""; // Clear existing cart items
    let total = 0;

    cart.forEach(item => {
        const cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.innerHTML = `
            <h3>${item.name}</h3>
            <p>Price: $${item.price} x ${item.quantity}</p>
            <button onclick="removeFromCart(${item.id})">Remove</button>
        `;
        cartContainer.appendChild(cartItem);
        total += item.price * item.quantity;
    });

    totalPrice.textContent = total.toFixed(2);
}

// Function to remove item from the cart
function removeFromCart(itemId) {
    cart = cart.filter(item => item.id !== itemId);
    updateCartCount();
    displayCart();
}

// Function to checkout
function checkout() {
    alert("Thank you for your order!");
    cart = [];
    updateCartCount();
    displayCart();
}

// Call displayCart() to show cart items when the page loads
displayCart();
